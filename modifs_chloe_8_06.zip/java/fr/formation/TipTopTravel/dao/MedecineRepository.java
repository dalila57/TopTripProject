package fr.formation.TipTopTravel.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.formation.TipTopTravel.entity.Medecine;

public interface MedecineRepository extends JpaRepository<Medecine, Integer>{

}
