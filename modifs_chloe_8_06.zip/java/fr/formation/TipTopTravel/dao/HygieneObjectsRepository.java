package fr.formation.TipTopTravel.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.formation.TipTopTravel.entity.HygieneObjects;

public interface HygieneObjectsRepository extends JpaRepository<HygieneObjects, Integer>{

}
