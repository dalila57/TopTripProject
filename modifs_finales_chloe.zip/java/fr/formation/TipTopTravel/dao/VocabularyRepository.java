package fr.formation.TipTopTravel.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.formation.TipTopTravel.entity.Vocabulary;

public interface VocabularyRepository extends JpaRepository<Vocabulary, Integer>{

}
