package fr.formation.TipTopTravel.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.formation.TipTopTravel.entity.City;

public interface CityRepository extends JpaRepository<City, Integer>{

}
