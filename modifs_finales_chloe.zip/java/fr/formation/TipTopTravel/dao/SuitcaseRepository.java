package fr.formation.TipTopTravel.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.formation.TipTopTravel.entity.Suitcase;

public interface SuitcaseRepository extends JpaRepository<Suitcase, Integer>{

}
