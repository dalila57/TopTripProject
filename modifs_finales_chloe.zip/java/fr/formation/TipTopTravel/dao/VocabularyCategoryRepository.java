package fr.formation.TipTopTravel.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.formation.TipTopTravel.entity.VocabularyCategory;

public interface VocabularyCategoryRepository extends JpaRepository<VocabularyCategory, Integer>{

}
