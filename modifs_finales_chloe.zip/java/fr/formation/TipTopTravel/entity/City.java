package fr.formation.TipTopTravel.entity;

import java.io.Serializable;

public class City implements Serializable {
	
	private static final long serialVersionUID=1L; 
		
	private Integer cityID;
	private String cityName;

	/**
	 * @return the cityID
	 */
	public Integer getCityID() {
		return cityID;
	}
	/**
	 * @param cityID the cityID to set
	 */
	public void setCityID(Integer cityID) {
		this.cityID = cityID;
	}
	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}
	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
	
	

}
