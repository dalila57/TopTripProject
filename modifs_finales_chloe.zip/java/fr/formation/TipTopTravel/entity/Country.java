/**
 * 
 */
package fr.formation.TipTopTravel.entity;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

/**
 * @author les_explorateurs
 *
 */
public class Country implements Serializable {
	
	private static final long serialVersionUID=1L;
	/**
	 * Identifiant du pays
	 */
	private Integer countryID;
	
	/**
	 * Nom du pays
	 */
	private String countryName;
	
	/**
	 * Numéro d'urgence relatif au pays
	 */
	private Integer emergencyNumber;
	
	private String money;
	
	private String timeZone;
	
	private Suitcase suitcase;
	
	private Set<City> cityList;

	/**
	 * @return the countryID
	 */
	public Integer getCountryID() {
		return countryID;
	}

	/**
	 * @param countryID the countryID to set
	 */
	public void setCountryID(Integer countryID) {
		this.countryID = countryID;
	}

	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}

	/**
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	/**
	 * @return the emergencyNumber
	 */
	public Integer getEmergencyNumber() {
		return emergencyNumber;
	}

	/**
	 * @param emergencyNumber the emergencyNumber to set
	 */
	public void setEmergencyNumber(Integer emergencyNumber) {
		this.emergencyNumber = emergencyNumber;
	}

	/**
	 * @return the money
	 */
	public String getMoney() {
		return money;
	}

	/**
	 * @param money the money to set
	 */
	public void setMoney(String money) {
		this.money = money;
	}

	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}

	/**
	 * @param timeZone the timeZone to set
	 */
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	/**
	 * @return the suitcase
	 */
	public Suitcase getSuitcase() {
		return suitcase;
	}

	/**
	 * @param suitcase the suitcase to set
	 */
	public void setSuitcase(Suitcase suitcase) {
		this.suitcase = suitcase;
	}

	/**
	 * @return the cityList
	 */
	public Set<City> getCityList() {
		return cityList;
	}

	/**
	 * @param cityList the cityList to set
	 */
	public void setCityList(Set<City> cityList) {
		this.cityList = cityList;
	} 
	
	
	

}
